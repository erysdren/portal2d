
#include <io.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <gl\glaux.h>
#include <ddraw.h>

#include "../source/level.h"
#include "../source/object.h"
#include "../source/fix.h"

object_t* camera = &objects[1];

palette_t palette;
GLuint image_ids[MAX_TEXTURE];

polygon_t poly_normal;

char* glTexture(picture_t* picture, palette_t palette)
{
  int x, y;
  static char buf[256 * 256 * 3];
  char* p = buf;

  for (y = 0; y < picture->height; y++)
  {
    for (x = 0; x < picture->width; x++)
    {
      int c = picture->scanlines.b[y][x];
      *p++ = palette[c][0];
      *p++ = palette[c][1];
      *p++ = palette[c][2];
    }
  }
  return buf;
}

void glPolygonRender(polygon_t src, int n, surface_t* surface)
{
  polygon_t polygon;
  
  n = polygon_clip_to_frustum(polygon, src, n);
  
  if (n > 2)
  {
    int i;
    float l = ((surface->light + 16) & 31) / 30.0;
 
    glBindTexture(GL_TEXTURE_2D, image_ids[surface->tid]);
    glBegin(GL_POLYGON);
    for (i = 0; i < n; i++)
    {      
      glColor3f(l, l, l);
      glTexCoord2f(f2fl(polygon[i].u + surface->panningx) / 256, f2fl(polygon[i].v + surface->panningy) / 256);
      glVertex3f(f2fl(polygon[i].x), f2fl(polygon[i].y), -f2fl(polygon[i].z));
    }
    glEnd();
  }
}

void wall_render_texture(int wid)
{
  int n;
  
  assert(wid);    
  
  if (walls[wid].visible)
  {
    if (walls[wid].port)
    {      
      poly_normal[0] = walls[wid].poly[3]; //wall_polys[walls[wid].port][2];
      poly_normal[1] = walls[wid].poly[2]; //wall_polys[walls[wid].port][3];  
      poly_normal[2] = walls[wid].poly[2];
      poly_normal[3] = walls[wid].poly[3];

      if (walls[walls[wid].port].poly[2].y > poly_normal[0].y)
      {
        poly_normal[0]   = walls[walls[wid].port].poly[2];
        poly_normal[0].u = walls[walls[wid].port].poly[3].u;
      }
      if (walls[walls[wid].port].poly[3].y > poly_normal[1].y)
      {
        poly_normal[1]   = walls[walls[wid].port].poly[3];
        poly_normal[1].u = walls[walls[wid].port].poly[2].u;
      }      
      //poly_normal[0].u = wall_polys[walls[wid].port][3].u;
      //poly_normal[1].u = wall_polys[walls[wid].port][2].u;
                                
      glPolygonRender(poly_normal, 4, &walls[wid].surface);
      
      poly_normal[0] = walls[wid].poly[0];
      poly_normal[1] = walls[wid].poly[1];  
      poly_normal[2] = walls[walls[wid].port].poly[0];
      poly_normal[3] = walls[walls[wid].port].poly[1];

      poly_normal[2].u = walls[walls[wid].port].poly[1].u;
      poly_normal[3].u = walls[walls[wid].port].poly[0].u;
                                
      glPolygonRender(poly_normal, 4, &walls[wid].surface);      
    }
    else
    {  
      glPolygonRender(walls[wid].poly, 4, &walls[wid].surface);     
    }
  }
}

void sector_render_walls(int sid)
{    
  int first_wall = FIRST_WALL(sid), wid = first_wall;

  do wall_render_texture(wid); while ((wid = NEXT_WALL(wid)) != first_wall);  
}

void gl_sector_render_ceiling(int sid)
{    
  glPolygonRender(poly_normal, sector_extrude_ceiling(sid, poly_normal), &sectors[sid].ceiling);  
}

/*
** name: sector_render_floor
** desc: render the floor of a sector.
*/
void gl_sector_render_floor(int sid)
{  
  glPolygonRender(poly_normal, sector_extrude_floor(sid, poly_normal), &sectors[sid].floor);  
}

/*
** name: gl_sector_render
** desc: render all the components of a sector.
*/
void gl_sector_render(int sid)
{
  assert(sid && FIRST_WALL(sid));
    
  sector_render_walls  (sid);
  gl_sector_render_floor  (sid);
  gl_sector_render_ceiling(sid);
  // TODO: Render sprites and 3d objects. Concave objects will need to be zbuffered otherwise, create
  // a BSP tree for the objects. I'd prefer to split concave object into small convex objects and
  // do a z-depth sort. That way we don't need a zbuffer and objects can be exploded.  
}  

void gl_render_view(object_t* camera)
{
  int i;  
  
  if (camera->sid)
  {    
    sector_calc_vis(camera);                
    
    for (i = sector_vis_count; i--; sector_transform(sector_vis[i], camera));
    for (i = sector_vis_count; i--; gl_sector_render(sector_vis[i]));
  }
  //console_render();
}

void CALLBACK MainLoop(void)
{        
  glClear(/*GL_COLOR_BUFFER_BIT |*/ GL_DEPTH_BUFFER_BIT);
  gl_render_view(camera);    
  glFlush();
  auxSwapBuffers();
}

void CALLBACK IdleFunc(void)
{
  if (GetAsyncKeyState('S') < 0) camera->ax += 4;
  if (GetAsyncKeyState('X') < 0) camera->ax -= 4;    
  if (GetAsyncKeyState('A') < 0) camera->zz += 20000;
  if (GetAsyncKeyState('Z') < 0) camera->zz -= 20000;  
  if (GetAsyncKeyState(VK_LEFT ) < 0) camera->ay -= 10;
  if (GetAsyncKeyState(VK_RIGHT) < 0) camera->ay += 10;
  
  if (GetAsyncKeyState(VK_UP) < 0)
  {
    camera->xx += muldiv(fixsin(camera->ay), 8, 8);
    camera->yy += muldiv(fixcos(camera->ay), 8, 8);
  }
  if (GetAsyncKeyState(VK_DOWN) < 0)
  {
    camera->xx -= muldiv(fixsin(camera->ay), 8, 8);
    camera->yy -= muldiv(fixcos(camera->ay), 8, 8);
  }    
  camera->xx -= (camera->xx / 13);      
  camera->yy -= (camera->yy / 13);
  camera->zz -= (camera->zz / 13);
  
  object_update(camera);

  MainLoop();
}

void CALLBACK ReshapeFunc(int width, int height)
{
  if (height)
  {    
    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(75.0, 1.0 * width / height, 0.001, 30.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity ();
    //glTranslatef (0.0, 0.0, -1);  /*  move object into view   */    
  }
}

GLfloat fogColor[4] = {0.0, 0.0, 0.0, 0.0};

void Init(void)
{
  int i;
  string_t s;
  
  glClearColor(0, 0, 0, 0);
  glShadeModel(GL_SMOOTH);

  glDepthFunc(GL_LESS);
  glClearDepth(1.0);
  glEnable(GL_DEPTH_TEST);
    
  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

  for (i = 0; i < MAX_TEXTURE; i++)
  {
    sprintf(s, "../textures/%d.bmp", i);
    if (!access(s, 0))
    {
      picture_load_from_file(&textures[i][0], s, palette);
      glGenTextures(1, &image_ids[i]);
      glBindTexture(GL_TEXTURE_2D, image_ids[i]);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);      
      glTexImage2D(GL_TEXTURE_2D, 0, 3,
        textures[i][0].width,
        textures[i][0].height, 0, GL_RGB, GL_UNSIGNED_BYTE, glTexture(&textures[i][0], palette));
    }
  }  
    
  glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
  glEnable(GL_TEXTURE_2D);
  
  glFrontFace(GL_CCW);
  glCullFace(GL_FRONT);
  glEnable(GL_CULL_FACE);     

  glEnable(GL_FOG);
  glFogi (GL_FOG_MODE, GL_LINEAR);
  glHint (GL_FOG_HINT, GL_FASTEST); 
  glFogf (GL_FOG_START, 0.0);
  glFogf (GL_FOG_END, 10.0);
  glFogfv (GL_FOG_COLOR, fogColor); 
  
  camera->sid = 0;
}

IDirectDraw* lpDD;

void main(void)
{
  RECT WR, CR;
  int x, y;  
  
  level_load_from_file("../test.map");
  
  auxInitDisplayMode(AUX_RGB | AUX_DOUBLE | AUX_DEPTH);  
  auxInitPosition(0, 0, 640, 480);
  auxInitWindow(0);

  DirectDrawCreate(NULL, &lpDD, NULL);
  
  lpDD->lpVtbl->SetCooperativeLevel(lpDD, auxGetHWND(), DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN);

  lpDD->lpVtbl->SetDisplayMode(lpDD, 640, 480, 16);

  GetWindowRect(auxGetHWND(), &WR);
  GetClientRect(auxGetHWND(), &CR);

  x = (WR.right  - WR.left) - CR.right ;
  y = (WR.bottom - WR.top ) - CR.bottom;
  
  MoveWindow(auxGetHWND(), -(x >> 1), -(y >> 1), 640, 480, 0);
      
  Init();
  
  auxExposeFunc(ReshapeFunc);
  auxReshapeFunc(ReshapeFunc);    
  auxIdleFunc(IdleFunc);
  auxMainLoop(MainLoop);
}

