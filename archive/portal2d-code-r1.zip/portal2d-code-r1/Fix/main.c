
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "fix.h"

#define M_PI (3.14159265358979323846)

void main(void)
{
  int i;
  
  printf("int sintable[] =\n{");
    
  for (i = 0; i < 2048; i++)
  {
    if (i) printf(",");
    if (!(i & 7)) printf("\n");
    printf("%d", fl2f(sin(i * M_PI / 1024.0)));   
  }
  printf("\n};\n\n");

  printf("short radarang[] =\n{");
      
  for(i = 0; i < 640; i++)
  {
    if (i) printf(",");
    if (!(i & 7)) printf("\n");    
    printf("%d", (short)(atan(((double)i-639.5)/160)*64*1024/3.14159265358979));    
  }
  printf("\n};\n\n"); 
}

